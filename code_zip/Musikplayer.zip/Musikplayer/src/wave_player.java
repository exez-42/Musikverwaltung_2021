
public class wave_player {
	
	// bekommt pathway und spielt ab
	
	
	
	//mehtode
	//play_titel(pathname){ play; }
	

}
