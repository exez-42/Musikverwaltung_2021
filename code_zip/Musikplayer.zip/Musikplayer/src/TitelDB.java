
public class TitelDB {
	
	
	
	//Variabelen:
	// hashmap die alle Titelobjekte enth�lt
	
	
	
	
	
	
	//Methode:
	//Konstruktor -> es darf nur eine TitelDB geben // Haben wir mal in einer �bung gemacht
	
	
	//Funktion   STATIC f�ge_titel_hinzu(titel objekt); (muss von Titel Klasse aufrufbar sein -> static)     F�gt titel Objekt in TITELDB ein;
	
	// Funktion  sortiere_nach(x,y); x = genre, titel, interpret, ...   y = String auswahl, BSP: x = Interpret y= Justin Bieber;  return Hashmap mit ergebnis
	//Funktion liefer_einzel_titel(Titel_ID){ return Titel}
	
	
	
	
	
	
	
	

}
