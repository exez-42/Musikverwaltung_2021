
public class Playlist {

	//Name
	//Hashmap mit Playlist titeln
	
	
	//Methoden:
	//Kontruktor{  erzeugt leere Hashmap   }
	/*Funktion add_titel_nach_sortiert(x,y); x = genre, titel, interpret,{
			
		hashmap = sortiere_nach(x,y);


		}*/
	
	
	//Funktion add einzelnen Titel 
		/* add_titel(Titel_id){
		
		hashmap.add(TitelDB.lieferTitel(TitelID));
		
		
		}
		*/
	
	
	
	//FUnktion delete_titel.....
	
	
	
}
