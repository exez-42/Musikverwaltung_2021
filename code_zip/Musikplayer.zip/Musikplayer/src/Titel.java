
public class Titel {
	
	//Variablen:
	//titelname
	//Genre
	//Album
	//releaseJahr
	//l�nge
	
	
	
	//Methoden:
	//kontruktor : f�gt automatisch jeden neuen Titel in TitelDB  ein;
	
	
	
	
	
	
}
