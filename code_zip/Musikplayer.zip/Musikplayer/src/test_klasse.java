
public class test_klasse {

}
