package musikverwaltung;

public class Wave_player {
	
	// bekommt pathway und spielt ab
	
	
	
	//mehtode
	//play_titel(pathname){ play; }
	

}