package musikverwaltung;

public class package_info {

}
